package com.example.bearnotesclone.data

data class Note(
    val id: Int,
    val title: String,
    val content: String,
    val timestamp: Long
)
