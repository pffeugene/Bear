
package com.example.bearnotesclone.viewmodel

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import com.example.bearnotesclone.data.Note

class NotesViewModel : ViewModel() {
    private val _notes = mutableStateListOf<Note>()
    val notes: List<Note> = _notes

    init {
        _notes.addAll(
            listOf(
                Note(1, "Добро пожаловать", "Это ваша первая заметка", System.currentTimeMillis()),
                Note(2, "Bear-style", "Минимализм + Markdown", System.currentTimeMillis())
            )
        )
    }

    fun addNote(note: Note) {
        _notes.add(note)
    }
}
